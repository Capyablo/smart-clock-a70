# A70 Smart Clock

Esta copia reúne el reloj PWA, el tiempo y las alarmas guardadas localmente con un primer asistente por voz. No necesita instalar paquetes ni mantener el PC encendido una vez publicada en un alojamiento HTTPS gratuito.

## Probar en Windows

1. Abre esta carpeta en Visual Studio Code.
2. Abre **Terminal → Nueva terminal**.
3. Escribe `node server.js` y pulsa Intro.
4. En el navegador del PC visita `http://localhost:4173`.
5. Pulsa el micrófono y permite el acceso al micrófono cuando el navegador lo solicite.

Para detener el servidor de prueba, vuelve a la terminal y pulsa **Ctrl+C**. El servidor del PC solo sirve para probar; el Galaxy no podrá llegar a él cuando el PC esté apagado.

## Llevarlo al Galaxy A70

La página debe estar publicada en una dirección **HTTPS** para instalarla y usar el micrófono. La carpeta contiene los archivos listos para publicar como sitio estático gratuito en un proveedor que sirva HTTPS. Al tener la dirección, ábrela en Chrome del Galaxy, concede el micrófono, toca **⋮ → Añadir a pantalla de inicio** y gira el móvil a horizontal.

La voz de este paso funciona pulsando el botón del micrófono. Reconoce consultas de hora, fecha, tiempo y alarmas; las respuestas se leen en voz alta. No escucha continuamente ni ofrece conversación general con IA. En Chrome móvil, la disponibilidad del reconocimiento depende de la versión del navegador, el permiso del micrófono y, a veces, conexión a Internet.

## Límites que conviene conocer

- El tiempo usa Open-Meteo y pide permiso de ubicación.
- Las alarmas se guardan en el teléfono, pero solo pueden sonar mientras la página esté abierta y Android no la haya suspendido. Para un despertar fiable con pantalla apagada o aplicación cerrada se necesita una alarma de Android nativa.
- El navegador no mantiene un micrófono escuchando en segundo plano de forma fiable.
- Calendario y controles de música aún no están conectados. Se añadirán en pasos posteriores, con permisos y compatibilidad evaluados antes.
- No se usa el antiguo Worker de IA porque el sitio de aquella versión mostró una advertencia de seguridad en Chrome. Esta copia no depende de él.
